# ADR-0003: Require openly readable normative dependencies

**Status:** Accepted  
**Accepted:** 2026-11-04  
**Reviewed for:** v0.2.1 Working Draft

## Context

The project aims to be open and independently implementable by environmental agencies, repositories, citizen-science organisations, researchers and software teams. Some relevant standards, notably ISO/IEC 5259, are copyright restricted. Others, including CF and many W3C/OGC/community specifications, are openly readable.

## Decision

All requirements necessary to implement or assess against this project must be stated openly in project material or through openly readable normative dependencies. Restricted standards may be informative references and may be crosswalked, but are not required for project conformance.

## Consequences

- ISO/IEC 5259 is informative rather than normative.
- The repository must not reproduce copyrighted normative text without permission.
- Alignment may be described conceptually and through public/open material.
- Future formal criteria and schemas must remain independently implementable without purchasing a restricted standard.
