# ADR-0001: Define AI-readiness independently and build on existing community work

**Status:** Accepted  
**Accepted:** 2026-11-04  
**Reviewed for:** v0.2.1 Working Draft

## Context

Several established initiatives address AI-ready data, notably ESIP for environmental/Earth science and ODI more generally. Defining AI-readiness as conformance to this project's own specification would be circular and would risk creating a competing generic checklist.

## Decision

Define AI-readiness independently of the project specification. Position the project as a water/environmental operationalisation and use-fitness layer that reuses existing community standards and guidance wherever adequate. ESIP v1.1 is the primary baseline for generic environmental AI-readiness questions.

## Consequences

- The project crosswalks before inventing criteria.
- New project-specific criteria require a documented residual gap.
- Claims of novelty are restricted to features not already provided elsewhere.
- v0.2.1 operationalises the residual-gap requirement in the conceptual model and crosswalk rather than creating a duplicate ADR.
