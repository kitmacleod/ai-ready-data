# Worked examples

Worked examples test and refine the conceptual model before software implementation.

## Primary cases

- HadUK-Grid bounded variable/version/use case.
- NRFA-style hydrometric time series.
- Riverfly RMI bounded citizen-science biological observation case.

## Challenge cases

- Abstraction/use data at a resolution inappropriate to a finer-scale use.
- Shared or protected water-utility data.

## Minimum contents of a worked example

Each example should include:

1. assessment target;
2. intended use statement;
3. target facets and applicability decisions;
4. evidence inventory, including source/version and retrieval date;
5. delegated standards/validator findings retained in native form;
6. residual project criteria actually required;
7. criterion results and evidence bases;
8. items requiring domain judgement;
9. specific-use requirement verdicts;
10. improvement actions and closing evidence;
11. reviewer disagreements/notes;
12. exclusions and unassessed questions.

Examples should distinguish **assessment plans** from **completed assessments**. An assessment plan must not contain invented verdicts or imply that evidence has been inspected when it has not.
