# HadUK-Grid bounded assessment plan

**Status:** Plan only. No assessment verdicts are claimed.  
**Specification checkpoint:** v0.2.1-working-draft

## 1. Purpose

Use a bounded HadUK-Grid case to test whether the conceptual model produces useful, evidence-backed distinctions beyond generic metadata conformance.

The pilot is deliberately chosen because it contains a strong falsification test for simplistic readiness logic: a product may expose a nominal 1 km grid and be distributed as CF-compliant netCDF while the production paper explicitly warns that the grid spacing does not represent the effective resolution of the underlying station observations.

## 2. Provisional assessment target

The target must be bound to an exact published version and retrieved resources before assessment. Until then, version/resource fields remain unresolved.

```yaml
assessment_target:
  product: HadUK-Grid
  product_version: TBD
  variable: rainfall
  temporal_frequency: daily
  nominal_spatial_resolution: 1km
  representation: CF-netCDF
  geographic_scope: UK
  temporal_scope: TBD
  resources: []
```

The 2019 data paper describes HadUK-Grid v1.0.0.0 and should be treated as product/method evidence, not proof that later releases have identical contents or limitations.

## 3. Provisional intended use

```yaml
specific_use:
  task_class: prediction_classification_or_estimation
  mode: exploratory_research
  use_description: >
    Use daily gridded precipitation as an explanatory or predictor
    variable in a hydrological machine-learning workflow.
  target_geography: TBD
  target_period: TBD
  required_spatial_support: TBD
  required_temporal_support: daily
  acceptable_missingness: TBD
  uncertainty_requirement: Material sampling, interpolation and known
    structural limitations must be visible to the analyst.
  human_oversight: domain expert involved in interpretation
```

This use statement is intentionally incomplete. The pilot must resolve the TBD fields before issuing fitness verdicts.

## 4. Primary evidence to collect

### Product identity and access

- authoritative catalogue/landing-page record for the selected HadUK-Grid release;
- selected version identifier and publication/update date;
- licence and attribution terms;
- actual data file(s) or stable access endpoint used for inspection;
- checksums/content hashes where practical.

### Scientific representation

- CF `Conventions` declaration;
- maintained CF-checker output and checker version;
- variable standard name, units and missing-value encoding;
- horizontal CRS/grid mapping;
- temporal coordinate, calendar, bounds and cell methods;
- relevant spatial coordinate/bounds semantics;
- any quality, status or uncertainty ancillary variables.

### Production and quality

- source observations and preprocessing method;
- gridding/interpolation method;
- station-network density/change evidence relevant to the selected period;
- QC process and known limitations;
- versioning/change information;
- published uncertainty, homogeneity or validation evidence.

## 5. Known questions from the production paper

The pilot should test, not assume answers to, at least these questions:

1. **Daily precipitation semantics**: is the represented observation interval explicit and correctly encoded for the selected files?
2. **Nominal versus effective resolution**: what spatial information scale can the station network and interpolation method support for the selected period and use?
3. **Network change**: does changing station density materially affect comparability or the intended ML use?
4. **QC scope**: are QC methods, flags and limitations sufficiently visible for the target/use?
5. **Provenance**: can the selected gridded values be related to the documented inputs and production method with sufficient specificity?
6. **Homogeneity and structural uncertainty**: what evidence exists, and what remains a domain judgement?
7. **Version reproducibility**: can the exact product used in an ML workflow be reconstructed or cited later?

## 6. Delegated checks

Where applicable, retain native results rather than recreating them.

| Concern | Preferred external mechanism | Project handling |
| --- | --- | --- |
| netCDF/CF representation | released CF version + maintained CF checker | retain checker finding/version as evidence |
| units, variable identity, coordinates, time, CRS, bounds/cell semantics | CF | do not duplicate CF rules |
| general AI-ready baseline questions | ESIP v1.1 | map responses/evidence before adding AIR criteria |
| discovery/assets | repository catalogue; STAC if actually published/applicable | profile rather than require STAC by default |
| package/context/provenance | provider documentation; RO-Crate if actually present/applicable | evaluate available evidence, do not invent crate requirement |
| ML consumption metadata | Croissant/GeoCroissant if present/appropriate | treat as complementary evidence |

## 7. Candidate residual questions to test

These are hypotheses, not yet formal normative criteria.

### R1 Effective spatial resolution is characterised for the intended use

**Why residual:** encoded grid spacing and bounds do not establish the independent observational information scale supported by the station network and interpolation process.

**Likely home:** D1.

**Potential evidence:** production paper; station-density information; interpolation-error or effective-resolution studies; provider declaration; domain review.

### R2 Changes in observing support are visible where material

**Why residual:** machine-readable temporal coverage does not establish stability of the underlying network or sampling support through time.

**Likely home:** D1/D5, with one eventual criterion home only.

### R3 Production/QC limitations are evaluable against the use

**Why residual:** existence of QC documentation or flags does not determine whether the remaining limitations are acceptable for the selected hydrological ML use.

**Likely home:** D5 plus specific-use fitness comparison.

### R4 Exact training input can be re-established

**Why residual:** product versioning may exist, but reproducible ML use requires an exact bound target/evidence snapshot.

**Likely home:** D2 or D5, depending on the final criterion wording.

## 8. Assessment sequence

1. Resolve and freeze the exact product version and resource(s).
2. Freeze the specific-use statement sufficiently to evaluate spatial/temporal requirements.
3. Build the evidence inventory with timestamps and hashes where practical.
4. Run delegated validation first, especially CF.
5. Map ESIP questions and other prior art to the collected evidence.
6. Identify only the residual questions not answered by delegated evidence.
7. Evaluate residual criteria and record domain judgements separately.
8. Compare established findings against each explicit use requirement.
9. Record improvement actions with closing evidence.
10. Obtain one independent domain/data-steward review and retain disagreements.

## 9. Expected pilot outputs

The completed pilot should produce:

- a frozen target/use manifest;
- an evidence inventory;
- native external-validator findings;
- a small set of genuinely residual AIR findings, if any;
- requirement-level fitness verdicts;
- explicit unresolved judgements;
- improvement actions;
- reviewer notes;
- recommended changes, if any, to the conceptual model.

## 10. Success test for the framework

The pilot is useful if it can distinguish at least the following without resorting to an opaque score:

- technically well-encoded evidence;
- scientifically meaningful limitations;
- questions that can be answered deterministically;
- questions that require provider declaration;
- questions that require domain judgement;
- specific-use mismatches;
- practical actions that would improve evidence or usability.

If the model cannot represent the nominal/effective-resolution issue clearly, or if it requires duplicating CF rules to do so, v0.2.1 should be considered conceptually inadequate and revised before a criteria register is formalised.
