# Prior-art and standards crosswalk

**Status:** v0.2.1 Working Draft, completed first pass.  
**Purpose:** determine what the project genuinely needs to add by mapping AI-readiness questions to existing community guidance and technical standards. The preferred outcome is often **reuse**, not a new AIR criterion.

## Decision values

- **ADOPT**: existing approach is sufficient for the question.
- **PROFILE**: reuse with water/environmental applicability or implementation guidance.
- **EXTEND**: existing mechanism covers part of the need; a documented residual remains.
- **DIFFER**: deliberate project difference with recorded rationale.
- **VERIFY**: detailed primary-source review is still required before normative reliance.

## Crosswalk rules for v0.2.1

1. An external mechanism may provide **evidence** without becoming a project criterion.
2. A project-specific criterion requires a documented residual gap.
3. Native findings from maintained validators should be retained with source/tool/version.
4. A standards failure is not automatically an AI-readiness failure; materiality must be established by an AIR criterion or use requirement.
5. Blank or VERIFY mappings must not be treated as proof that an external standard has a gap.
6. The six AIR dimensions provide criterion homes, not the crosswalk's logic.

## First-pass crosswalk

| Need / ESIP area | Existing mechanism | Decision | Residual question / project treatment | Likely AIR location |
| --- | --- | --- | --- | --- |
| Assessment granularity | ESIP v1.1 minimum measurable bundle; pragmatic file-level manual assessment | ADOPT + EXTEND | Define an explicit target, version, representation and scope of conclusions | cross-cutting target model |
| Dataset version and raw/derived status | ESIP General Information | ADOPT | Record exact target/version in the assessment manifest and evidence snapshot | D2/D5 |
| Spatial/temporal extent | ESIP Quality/Documentation; CF coordinates/bounds where applicable | ADOPT/PROFILE | Encoded extent may not equal relevant scientific support for a use | D1 + fitness |
| Spatial/temporal resolution | ESIP Quality; CF coordinates, bounds and cell methods | EXTEND | Distinguish nominal encoding resolution from effective informational/observational resolution | D1 + fitness |
| Missing-value encoding | ESIP Preparation; CF `_FillValue`, `missing_value`, valid range | ADOPT/PROFILE | Separate encoding from the scientific cause and use impact of missingness | D2 then D1/fitness |
| Variable meaning | ESIP Documentation; CF `standard_name`, units, `long_name` | ADOPT/PROFILE | Shared identifiers/units do not prove scientific comparability across products | D3 + fitness |
| Time semantics | CF time units, calendar, bounds and cell methods | ADOPT/PROFILE | Domain conventions such as observation-day definitions still need interpretation against the use | D2/D3 + fitness |
| CRS/geolocation | CF coordinates and grid mappings; CRS standards | ADOPT | Confirm vertical/reference requirements where material; otherwise delegate | D2 |
| Cell support/aggregation semantics | CF bounds, cell methods and cell measures | ADOPT/PROFILE | Use may require scientific interpretation of what the aggregation or support implies | D1/D2 + fitness |
| QC/status flags | CF ancillary variables and flags; ESIP quality procedures | ADOPT/PROFILE | Determine whether available QA/QC evidence is sufficient for the use | D5 + fitness |
| File-level uncertainty variables | CF ancillary variables/standard-name modifiers | ADOPT/PROFILE | Preserve CF-native encoding when present | D5 |
| Sampling/model/structural uncertainty | ESIP Quality; provider scientific documentation | EXTEND | Characterise uncertainty and limitations that are not reducible to file-level encoding | D5 + fitness |
| Bias/representativeness | ESIP Quality | PROFILE/EXTEND | Evaluate against the target population/phenomenon and intended use; domain judgement may be required | D1 + fitness |
| Provenance | ESIP; CF `source`, `history`, `references`; RO-Crate/PROV candidates | EXTEND | Define sufficient end-to-end lineage and assessment evidence provenance without duplicated metadata | D5 |
| Integrity/fixity | ESIP checksums; repository/package mechanisms | ADOPT/PROFILE | Evidence bundle additionally needs retrieval time and snapshot/hash identity | D2/D5 + assessment record |
| Dataset discovery | ESIP Documentation; repository catalogues; STAC for suitable spatiotemporal assets | PROFILE | Select discovery mechanism by target type rather than requiring STAC universally | D4 |
| Access/download | ESIP Access | ADOPT/PROFILE | Assess whether documented mechanism works for the target; separate this from use-specific performance | D4 |
| API/subsetting | ESIP Access; OGC/open APIs; STAC API where appropriate | PROFILE | API is not universally required; assess according to target/use and operational need | D4 + use class |
| Operational reliability/latency | Service evidence; provider declarations/monitoring | EXTEND | Availability, latency, rate limits and change behaviour are context/use dependent | D4 + use class/fitness |
| Restricted data | ESIP restricted-data questions | ADOPT + EXTEND | Protected access is not an automatic readiness failure; expose access route, controls and evidence strength | D4/D6 |
| Machine-readable dataset metadata | ESIP Documentation; CF for in-file science; Croissant/DCAT/schema.org candidates externally | PROFILE/VERIFY | Avoid duplicate authoritative metadata; determine target-appropriate representation | D2/D3 |
| ML-oriented consumption metadata | ESIP Preparation; Croissant/GeoCroissant | VERIFY/PROFILE | Use-pattern-specific consumption metadata should reference authoritative science/assets | use class / D2 |
| Recommended/non-recommended uses | ESIP Documentation | ADOPT + EXTEND | Compare declarations and limitations with structured specific-use requirements | fitness layer |
| Example code/notebooks | ESIP Documentation | ADOPT | Treat as usability evidence, not proof of scientific fitness | D4 supporting evidence |
| Labels/targets | ESIP Preparation; Croissant/STAC label approaches | PROFILE/VERIFY | Apply only where supervised-learning semantics are relevant | use class / D2-D3 |
| Data splits/evaluation guidance | ESIP direction of travel and ML metadata approaches | PROFILE/EXTEND | Needed only for relevant ML uses; spatial/temporal autocorrelation may make generic random splits inappropriate | use class / fitness |
| Licence/usage rights | ESIP Documentation/Access; machine-readable rights mechanisms | ADOPT/PROFILE | Keep access class separate from permitted use; no automated legal conclusion | D6 |
| Governance roles and contacts | ESIP contacts; ODI; ISO 5259 informative | PROFILE/EXTEND | Authority for declarations, overrides, corrections and feedback should be explicit | D6 |
| Privacy/security | ESIP restricted-data questions; applicable law/policy; ODI informative | PROFILE | Requirements are target/context dependent; do not import personal-data assumptions into physical data | D6 |
| Dataset update/version history | ESIP timeliness/revision questions; repository/product versioning | ADOPT/PROFILE | Reproducible assessment needs exact target version/snapshot and observed evidence date | D2/D5 |
| Assessment reproducibility | Project-specific; stable records/hashes patterns from Data Director and scientific assessment literature | EXTEND | Evidence snapshot + specification/check versions + deterministic evaluation + manifest | cross-cutting assessment model |
| Human/domain judgement | ESIP qualitative questions; practitioner pilot evidence | EXTEND | Record judgement as first-class, attributed evidence rather than hiding it inside a score | cross-cutting |
| Improvement guidance | ESIP direction of travel; project-specific action model | EXTEND | Link finding to actor, action, closing evidence, use effect and reassessment | cross-cutting action model |
| Composite readiness score/badge | Some external frameworks use scores or labels | DIFFER | Project avoids a universal aggregate because weights and materiality are use dependent | output model |
| Open normative implementability | Open standards where possible; restricted ISO material informative | EXTEND | Project-specific open-dependency rule ensures the method is independently implementable | governance/specification |

## CF delegation profile

Where CF applies, AIR should not recreate the following classes of CF rules:

- variable identity through standard names and units;
- space/time coordinates and calendars;
- CRS/grid mapping representation;
- cell bounds, measures and statistical cell methods;
- missing-value encoding;
- ancillary uncertainty/status/quality variables and flag encodings;
- discrete sampling geometry structure and feature identifiers;
- CF-native provenance/description attributes to the extent that CF defines them.

The relevant released CF version and a maintained checker should be recorded with the finding. AIR assesses residual scientific meaning, sufficiency, limitations and use impact where CF stops.

## ESIP relationship

ESIP v1.1 remains the generic environmental checklist baseline. AIR should normally:

1. map the ESIP question to available evidence or an applicable external standard;
2. reuse that answer/finding where sufficient;
3. profile it for water/environmental applicability only where necessary; and
4. create an AIR criterion only where a residual assessment question remains.

## Roles of complementary mechanisms

The current working hypothesis, subject to detailed verification, is:

- **CF**: in-file scientific variables, coordinates, units, cell semantics, flags and related representation;
- **STAC**: discovery and inventory of suitable spatiotemporal assets;
- **RO-Crate**: package identity, relationships, context, citation and provenance;
- **Croissant/GeoCroissant**: ML-oriented consumption metadata that can refer to published assets/scientific metadata.

These mechanisms should not be forced into a single duplicate metadata record. One mechanism may reference evidence held authoritatively in another.

## Residual project layer after first pass

The crosswalk suggests that the genuinely distinctive layer is likely to concentrate on:

- explicit target bounding and scope of conclusions;
- effective resolution/scientific support rather than nominal encoding alone;
- use-relative representativeness and bias;
- structural/sampling uncertainty and material limitations outside standard file encodings;
- operational requirements that vary by use class;
- structured specific-use requirements and requirement-level verdicts;
- explicit, attributed domain judgement;
- reproducible evidence/assessment manifests;
- improvement actions tied to closing evidence and reassessment.

This is a hypothesis to test through pilots, not a frozen criteria list.

## Remaining VERIFY work

Before STAC, RO-Crate or Croissant become normative dependencies or supply formal criterion mappings, inspect their current primary specifications and maintained validators/implementations at field level. v0.2.1 intentionally does not infer requirements from product summaries or earlier project slides.

## Conclusion for v0.2.1

The six dimensions remain useful as an organising structure, but the primary assessment logic is:

```text
target
  -> applicability
  -> reused/delegated standards evidence
  -> residual criterion only where needed
  -> finding
  -> use requirement
  -> fitness verdict
  -> improvement action
  -> reassessment
```

The next design evidence must therefore come from a bounded manual assessment rather than expanding this crosswalk into a large project-specific checklist.
